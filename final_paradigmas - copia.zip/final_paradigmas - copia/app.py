from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from functools import wraps  # Para crear el decorador
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from datetime import datetime
from flask import send_from_directory
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Configuración de la base de datos
app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''  # Cambia esto si tienes contraseña
app.config['MYSQL_DB'] = 'ferreteria'

mysql = MySQL(app)

# Decorador para proteger rutas
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'usuario_id' not in session:  # Si no hay un usuario en la sesión
            return redirect(url_for('login'))  # Redirige al inicio de sesión
        return f(*args, **kwargs)
    return decorated_function

# Modelo base
class Producto:
    def __init__(self, id_producto, nombre, precio, imagen):
        self.id_producto = id_producto
        self.nombre = nombre
        self.precio = precio
        self.imagen = imagen

# Controlador
class Carrito:
    def __init__(self):
        if 'carrito' not in session:
            session['carrito'] = []

    def agregar_producto(self, producto):
        session['carrito'].append(producto.__dict__)
        session.modified = True

    def eliminar_producto(self, id_producto):
        session['carrito'] = [p for p in session['carrito'] if p['id_producto'] != id_producto]
        session.modified = True

    def obtener_carrito(self):
        return session.get('carrito', [])

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_user():
    correo = request.form['correo']
    contrasena = request.form['contrasena']

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id_usuario, usuario FROM usuarios WHERE correo=%s AND contrasena=%s", (correo, contrasena))
    user = cursor.fetchone()

    if user:
        session['usuario_id'] = user[0]  # Guarda el ID del usuario en la sesión
        session['usuario'] = user[1]    # Guarda el nombre del usuario
        return redirect(url_for('productos'))
    else:
        return "Usuario o contraseña incorrectos"

@app.route('/registro')
def registro():
    return render_template('registro.html')

@app.route('/registro', methods=['POST'])
def registrar_usuario():
    usuario = request.form['usuario']
    correo = request.form['correo']
    contrasena = request.form['contrasena']

    cursor = mysql.connection.cursor()
    cursor.execute("INSERT INTO usuarios (usuario, correo, contrasena) VALUES (%s, %s, %s)", (usuario, correo, contrasena))
    mysql.connection.commit()

    return redirect(url_for('login'))

@app.route('/productos')
@login_required
def productos():
    cursor = mysql.connection.cursor()

    # Consulta para obtener todas las categorías
    cursor.execute("SELECT id_categoria, nombre FROM categorias")
    categorias = cursor.fetchall()

    # Consulta para obtener los productos agrupados por categorías
    cursor.execute("""
        SELECT p.id_producto, p.nombre, p.precio, p.imagen, c.nombre AS categoria
        FROM productos p
        JOIN categorias c ON p.id_categoria = c.id_categoria
    """)
    productos = cursor.fetchall()

    # Organiza los productos por categoría
    productos_por_categoria = {}
    for producto in productos:
        categoria = producto[4]  # Nombre de la categoría
        if categoria not in productos_por_categoria:
            productos_por_categoria[categoria] = []
        productos_por_categoria[categoria].append(producto)

    return render_template('productos.html', productos_por_categoria=productos_por_categoria, categorias=categorias)

@app.route('/agregar_carrito/<int:id_producto>')
@login_required
def agregar_carrito(id_producto):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id_producto, nombre, precio, imagen FROM productos WHERE id_producto = %s", (id_producto,))
    producto = cursor.fetchone()

    if producto:
        p = Producto(*producto)
        carrito = Carrito()
        carrito.agregar_producto(p)
    return redirect(url_for('ver_carrito'))

@app.route('/carrito')
@login_required
def ver_carrito():
    carrito = Carrito()
    productos_en_carrito = carrito.obtener_carrito()
    total = sum([float(item['precio']) for item in productos_en_carrito])  # Convertimos precios a flotantes
    return render_template('carrito.html', carrito=productos_en_carrito, total=total)

@app.route('/eliminar_carrito/<int:id_producto>')
@login_required
def eliminar_carrito(id_producto):
    carrito = Carrito()
    carrito.eliminar_producto(id_producto)
    return redirect(url_for('ver_carrito'))

@app.route('/comprar', methods=['POST'])
@login_required
def comprar():
    carrito = Carrito()
    productos = carrito.obtener_carrito()

    cursor = mysql.connection.cursor()
    total = 0

    # Inserta los productos en la tabla compras y calcula el total
    for producto in productos:
        total += float(producto['precio'])
        cursor.execute(
            "INSERT INTO compras (id_producto, id_usuario, cantidad, nombre, precio) VALUES (%s, %s, %s, %s, %s)",
            (producto['id_producto'], session['usuario_id'], 1, producto['nombre'], float(producto['precio']))
        )
    mysql.connection.commit()

    ticket_path = generar_ticket(productos, total)

    session.pop('carrito', None)  # Limpia el carrito después de la compra

    return f"Compra realizada con éxito. <a href='/{ticket_path}' target='_blank'>Descargar Ticket</a>"

def generar_ticket(productos, total):
    ticket_dir = "tickets"
    if not os.path.exists(ticket_dir):
        os.makedirs(ticket_dir)

    now = datetime.now().strftime("%Y%m%d%H%M%S")
    ticket_path = os.path.join(ticket_dir, f"ticket_{now}.pdf")

    c = canvas.Canvas(ticket_path, pagesize=letter)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, 750, "FERRETERÍA ONLINE - TICKET DE COMPRA")
    c.setFont("Helvetica", 12)
    c.drawString(50, 735, f"Fecha y Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    c.drawString(50, 720, "------------------------------------------------------------")

    y = 700
    for producto in productos:
        c.drawString(50, y, f"Producto: {producto['nombre']}")
        c.drawString(300, y, f"Precio: ${producto['precio']}")
        y -= 20

    c.drawString(50, y, "------------------------------------------------------------")
    y -= 20
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y, f"TOTAL A PAGAR: ${total:.2f}")

    c.save()

    return ticket_path

@app.route('/tickets/<filename>')
@login_required
def descargar_ticket(filename):
    return send_from_directory('tickets', filename)

if __name__ == '__main__':
    app.run(debug=True)
