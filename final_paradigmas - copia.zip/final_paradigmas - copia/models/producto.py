class Producto:
    def __init__(self, id_producto, nombre, precio, imagen):
        self.id_producto = id_producto
        self.nombre = nombre
        self.precio = precio
        self.imagen = imagen
